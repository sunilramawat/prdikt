<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Category;
use App\Models\SubCategory;
use App\Traits\ApiResponse;
use App\Http\Controllers\Controller;
use App\Http\Utility\commonHelper;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Helpers\Custom;
use URL;

class CategoryController extends Controller
{
        
    use  ApiResponse;

    public function getMainCategory(){

        $commonHelper = new commonHelper();
        $categories= Category::get();
     
        $response = array();
        $categoryArray = array();

        foreach($categories as $category ){
            $categoryArray['id']    = $category->category_id ;
            $categoryArray['name']  = $category->category_name ;
            $categoryArray['image'] = URL::to('/').$commonHelper->getImagePath('category').$category->category_image ;
            array_push($response,$categoryArray);
        }
        return $this->success($response,$commonHelper->constant(200));

    }

    public function getSubCategory(Request $request){


        $commonHelper = new commonHelper();
        $subCategory  = SubCategory::findSubCategoryByCategoryId($request->get('categoryId'));

        $response = array();
        $subCategoryArray = array();

        foreach($subCategory as $category ){

            $subCategoryArray['id']    = $category->sub_category_id ;
            $subCategoryArray['name']  = $category->sub_category_name ;
            $subCategoryArray['image'] = URL::to('/').$commonHelper->getImagePath(
                                        'subcategory').$category->sub_category_image ;
            array_push($response,$subCategoryArray);
        }
        return $this->success($response,$commonHelper->constant(200));

    }
    
}
