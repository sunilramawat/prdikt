<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Models\User;
use App\Traits\ApiResponse;
use App\Http\Controllers\Controller;
use App\Http\Requests\API\LoginFormRequest;
use App\Http\Requests\API\RegisterFormRequest;
use App\Http\Requests\API\ForgotPasswordRequest;
use App\Http\Requests\API\ResetPasswordRequest;
use App\Http\Utility\commonHelper;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Helpers\Custom;
use Illuminate\Support\Str;
use App\Models\Token;
use URL;
class AuthController extends Controller
{
        
    use  ApiResponse;


    public  function  register(RegisterFormRequest  $request){
     
        $commonHelper = new commonHelper();
        $checkUserExist = User::where('email',$request->get('email'))
                          ->orwhere('phone',$request->get('phone'))->count();
        if($checkUserExist > 0 ){
            return $this->error($commonHelper->constant(403));
        }

        $user = new User();
        $user->name = $request->name;
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $user->phone = $request->phone;
        $user->save();

        $credentials = request([$user->email, $user->password]);
        $token = auth()->attempt($credentials);
        $user = auth()->guard('api')->user();
        $this->tokenCreated($user->id,$token);
        $user['accessToken'] = $token;
        return $this->success($user,$commonHelper->constant(200));

    }
    public function login(LoginFormRequest $request){

        $commonHelper = new commonHelper();
        $checkUser = User::where('phone',$request->get('phone'))
                    ->where('status',0)->first();

        if(!empty($checkUser)){


            if (! $token = auth()->guard('api')->attempt(['email' => $checkUser->email,'password' => $request->get('password')])){
                return $this->error($commonHelper->constant(401));
            }    


            $user = auth()->guard('api')->user();
            if($user->user_type == 'user'){
                $user['profile'] = URL::to('/public/images/users/'.$user->image);
                $user['accessToken'] = $token;
                $this->tokenCreated($user->id,$token);
                return $this->success($user,$commonHelper->constant(200));
            }

        }
        


        return $this->error($commonHelper->constant(423));
    }


    public function  doForgotPassword(ForgotPasswordRequest $request)
    {
       $user = new User();
       $commonHelper = new commonHelper();
       $getUser = $user->getUserByEmail($request->get('email'));

       if($getUser){
          $custom = new Custom();
          $code = rand (1000 , 9999 );
          $custom->sendResetPasswordMail($code,$request->get('email'));

          $getUser->forgot_password = $code;
          $getUser->save();

          return $this->success(NULL,$commonHelper->constant(200));
       
       }

      return $this->error($user,$commonHelper->constant(400));
       
    }

    public  function  doResetPassword(ResetPasswordRequest $request){
        $user = new User();
        $commonHelper = new commonHelper();
        $getUser = $user->getUserByCode($request->get('code'));

        if($getUser){

            $getUser->password = Hash::make($request->get('password'));
            $getUser->forgot_password = NULL;
            $getUser->save();


            return $this->success(NULL,$commonHelper->constant(200));
        }

        return $this->error($commonHelper->constant(601));

    }

    public function tokenCreated($userId,$token){

        $createdToken = new Token;
        $createdToken->token_user_id = $userId;
        $createdToken->token = $token;
        $createdToken->save();
    }
}
