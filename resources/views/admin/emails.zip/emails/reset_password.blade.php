
<html>
<head>
    <title></title>
</head>
<body>
<h3>{{ $details['title'] }}</h3>
<p>{{ $details['body'] }} &nbsp; {{ $details['link'] }}</p>
<!-- <p>{{ $details['body'] }}&nbsp;<a href="{{ $details['link'] }}"> Click Here</a></p>
 -->
<p>Thank you</p>
</body>
</html>
